module.exports = {
    googleClientID: "37893973662-ld7pnv6h1kljc2l7hldspt00orfequmj.apps.googleusercontent.com",
    googleClientSecret: "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",
    mongoURI: 'mongodb+srv://Sagameda:IjlqYbalVYkrNt5R@cluster0.ts6rktu.mongodb.net/emailydb?retryWrites=true&w=majority',
    cookieKey: 'loremasdasdasdasdasdasdad'
}